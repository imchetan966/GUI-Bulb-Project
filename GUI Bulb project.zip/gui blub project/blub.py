import tkinter as tk
from PIL import Image, ImageTk

# Window setup
root = tk.Tk()
root.title("Light Bulb Switch")
root.geometry("350x400")
root.configure(bg="black")

# Load images
bulb_on_img = Image.open("on.png")  # glowing bulb
bulb_off_img = Image.open("off.png")    # off bulb

bulb_on_photo = ImageTk.PhotoImage(bulb_on_img)
bulb_off_photo = ImageTk.PhotoImage(bulb_off_img)

# Image label
bulb_label = tk.Label(root, image=bulb_off_photo, bg="black")
bulb_label.pack(pady=20)

# State tracking
bulb_is_on = False

# Toggle function
def toggle_bulb():
    global bulb_is_on
    if bulb_is_on:
        bulb_label.config(image=bulb_off_photo)
        toggle_button.config(text="ON", bg="green", fg="white")
        bulb_is_on = False
    else:
        bulb_label.config(image=bulb_on_photo)
        toggle_button.config(text="OFF", bg="red", fg="white")
        bulb_is_on = True

# Toggle Button
toggle_button = tk.Button(root, text="ON", font=("Arial", 14), bg="green", fg="white",
                          width=10, command=toggle_bulb)
toggle_button.pack(pady=20)

root.mainloop()
